# cool_roof_project > 2024-04-12 3:28am
https://universe.roboflow.com/ktaivle5/cool_roof_project

Provided by a Roboflow user
License: CC BY 4.0

